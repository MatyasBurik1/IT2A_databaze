﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IT2A_databeze
{
    class Hra
    {
        public int ID { get; set; }
        public string Nazev { get; set; }
        public string Vydavatel { get; set; }
        public int Rok { get; set; }
        public string Typ {  get; set; }
        public int Cena { get; set; }
        public bool Vlastnena { get; set; }
    }
}
