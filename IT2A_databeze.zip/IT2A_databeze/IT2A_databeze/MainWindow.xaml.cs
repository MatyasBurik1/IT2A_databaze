﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IT2A_databeze
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary
    public partial class MainWindow : Window
    {
        int GameID = 1;
        int pocet = 0;
        ObservableCollection<Hra> hry = new ObservableCollection<Hra>();
        public MainWindow()
        {
            InitializeComponent();
            dataGrid.ItemsSource = hry;
        }
        private void AddGame_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(txtRok.Text, out int rok) || !int.TryParse(txtCena.Text, out int cena))
            {
                MessageBox.Show("Rok a cena musí být čísla!");
                return;
            }
            Hra nova = new Hra()
            {
                ID = GameID,
                Nazev = txtNazev.Text,
                Vydavatel = txtVydavatel.Text,
                Rok = int.Parse(txtRok.Text),
                Typ = txtTyp.Text,
                Cena = int.Parse(txtCena.Text),
                Vlastnena = chkVlastnena.IsChecked == true
            };

            hry.Add(nova);
            GameID ++;
            pocet ++;
        }
        private void LoadGame_Click(object sender, RoutedEventArgs e)
        {
            if (dataGrid.SelectedItem is Hra vybrana)
            {
                txtNazev.Text = vybrana.Nazev;
                txtVydavatel.Text = vybrana.Vydavatel;
                txtRok.Text = vybrana.Rok.ToString();
                txtTyp.Text = vybrana.Typ;
                txtCena.Text = vybrana.Cena.ToString();
                chkVlastnena.IsChecked = vybrana.Vlastnena;
            }
        }
        private void EditGame_Click(object sender, RoutedEventArgs e)
        {
            if (dataGrid.SelectedItem is Hra vybrana)
            {
                vybrana.Nazev = txtNazev.Text;
                vybrana.Vydavatel = txtVydavatel.Text;
                vybrana.Rok = int.Parse(txtRok.Text);
                vybrana.Typ = txtTyp.Text;
                vybrana.Cena = int.Parse(txtCena.Text);
                vybrana.Vlastnena = chkVlastnena.IsChecked == true;

                dataGrid.Items.Refresh();
            }
        }
        private void DeleteGame_Click(Object sender, RoutedEventArgs e)
        {
            if (dataGrid.SelectedItem is Hra vybrana)
            {
                hry.Remove(vybrana);
                pocet--;
            }
        }
        private void ClearForm_Click(Object sender, RoutedEventArgs e)
        {
            txtNazev.Text = "";
            txtVydavatel.Text = "";
            txtRok.Text = "";
            txtTyp.Text = "";
            txtCena.Text = "";
            chkVlastnena.IsChecked = false;
        }

    }
}